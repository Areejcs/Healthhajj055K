/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helathhajj;

import javax.swing.JFrame;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;
import java.net.MalformedURLException;
import java.net.URI;
import java.awt.Desktop;
import java.io.IOException;
import javax.swing.JPanel;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Areej
 */
public class Service extends JFrame implements ItemListener, ActionListener {
    
  static JLabel lbl0 = new JLabel("In case you need help please give us the location and conact us or cheack nearest clinic - في حالة حدوث حادث الرجا تحديد الموقع والاتصال او زيارة اقرب عيادة");
    static JLabel lbl1 = new JLabel("Map - خريطة الحج");
    static JButton FAQ = new JButton("FAQ");
    static JLabel lbl2 = new JLabel("للاستفسارات والتواصل");
    //static JButton pre = new JButton("Previous - السابق"); 
    static JPanel p = new JPanel();
    static JButton mapBtn = new JButton("Maps");
   static Desktop map = Desktop.getDesktop();
    
   public void openWebPage(String url){
   try {         
     java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
   }
   catch (java.io.IOException e) {
       System.out.println(e.getMessage());
   }
}
    public Service() throws URISyntaxException, IOException{
        setLayout(new FlowLayout());
        this.setTitle("Hajj Services - خدمات الحاج");
        setVisible(true);  
        setSize(660, 630);
         p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
         add(p);
         p.add(lbl0);
         p.add(lbl1);
        p.add(mapBtn);
         
       // هنا  الخريطة
 
        p.add(FAQ);
        p.add(lbl2);
  
        
        
        
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
   /* if(e.getSource()==mapBtn){
        if (Desktop.isDesktopSupported()){
         openWebPage("http://www.mywebsite.com/forum/");     
        } */

               if(e.getSource() == mapBtn){
                FAQ2 f = new FAQ2();
                setVisible(false);
                f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                f.setSize(300, 150);
            }    
    }
      }
    
    



   
        
    


