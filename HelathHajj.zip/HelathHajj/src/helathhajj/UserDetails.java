/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helathhajj;

import javax.swing.JFrame;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
/**
 *
 * @author Areej
 */
public class UserDetails extends JFrame implements ItemListener, ActionListener {
  
   // static JLabel lbl1 = new JLabel("Enter your code - لطفاالاشتراك الخاص بالحملةادخل رقم الاشتراك الخاص بالحملة");
   // static JLabel lbl2 = new JLabel("Enter your Id/Iqama number - لطفاادخل رقم الهوية الوطنية او الإقامة");
    static JPanel p = new JPanel ();
    static JRadioButton BU1 = new JRadioButton("Enter your code - لطفاالاشتراك الخاص بالحملةادخل رقم الاشتراك الخاص بالحملة");
    static JRadioButton BU2 = new JRadioButton("Enter your Id/Iqama number - لطفاادخل رقم الهوية الوطنية او الإقامة");
    static JTextField T1 = new JTextField(15);
   static ButtonGroup CodeType = new ButtonGroup();
   static JButton nxt = new JButton("Next - التالي"); 

  
   public UserDetails ()
{
        setLayout(new FlowLayout());
        this.setTitle("User Details - معلومات الحاج");
        setVisible(true);
      
        setSize(360, 230);
        p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        add(p);
        CodeType.add(BU1);
        CodeType.add(BU2);
        p.add(BU1);
        p.add(BU2);
        BU1.addItemListener(this);
        BU2.addItemListener(this);
        nxt.addActionListener(this);
        p.add(nxt);
      //  p.add(pre);
}
  @Override
        public void actionPerformed(ActionEvent e){
                  if(e.getSource() == nxt){
             UserDetails2 UD2 = new UserDetails2 ();
             UD2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             UD2.setSize(400,300);
              setVisible(false);
            }
            /*     if(e.getSource() == pre){
                Login LO = new Login();
                setVisible(false);
                LO.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                LO.setSize(500, 150);
            }  */
}

    @Override
    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}