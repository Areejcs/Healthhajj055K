/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package helathhajj;

import java.awt.*;
import javax.swing.*;
/**
 *
 * @author Areej
 */ 
public class FAQ2 extends JFrame {
static JLabel lbl1 = new JLabel("FAQ - الأسئلة الشائعه");
static JTextField txt1 = new JTextField("س/الحلول عند  الاصابه بالإجهاد العضلي نتيجة لمشاقه السفر وإذاء الفرائض؟ \n" +
"ج/ينصح بأقتناء مسكنات وأوديه باسطة للعضلات ومراهم\n" +
"\n" +
"س/ للوقائة من ضربات الشمس ؟\n" +
"ج/ الحرص على لَبْس نظاره شمسية ، غطاء للرأس ، مظلة \n" +
"\n" +
"\n" +
"س/الغذاء الأمثل خلال فترة الحج لتفادي التسمم  ؟\n" +
"ج/ يجب التأكد من صلاحية المواد الغذائيه المعلبة والمجمدة وتجنب شراء الأطعمة المكشوفة\n" +
"\n" +
"\n" +
"\n" +
"س/ للوقاية من الاجهاد الحراري؟\n" +
"ج/ ينصح بشرب النوبة بكثرة والسوائل حتى لاتسسب الجفاف");

static JFrame frm = new JFrame();
public FAQ2(){
    setLayout(new FlowLayout());
    frm.add(lbl1);
    txt1.setEditable(false);
    txt1.setSize(730, 450);
    frm.add(txt1);
    
}
    }
    

