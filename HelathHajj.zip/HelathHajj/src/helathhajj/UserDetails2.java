/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helathhajj;
import javax.swing.JFrame;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Areej
 */
public class UserDetails2 extends JFrame implements ItemListener, ActionListener /* throws URISyntaxException, IOException */ {

        static JPanel p = new JPanel();
        static JPanel p2 = new JPanel();
    static JLabel lbl1 = new JLabel ("Do you have these disases? - عزيزي الحاج هل انت مصاب احدى هذه الامراض؟");
    static JCheckBox lbl2 = new JCheckBox ("Diabetes - مرض السكري");
    static JCheckBox lbl3 = new JCheckBox ("Blood pressure - مرض الضغط");
   //    static ButtonGroup Qgroup2 = new ButtonGroup();
    static JCheckBox lbl4 = new JCheckBox ("Asthma - مرض الربو");
   // static ButtonGroup Qgroup3 = new ButtonGroup();
    static JLabel lbl5 = new JLabel ("Do you need a wheelchair? -  هل انت بحاجة الى كرسي متحرك؟ ");
      static JRadioButton BU1_4= new JRadioButton("Yes - نعم");
    static JRadioButton BU2_4 = new JRadioButton("No - لا");
    static ButtonGroup Qgroup4 = new ButtonGroup();
    static JLabel lbl6 = new JLabel ("Do you other disases want us to know? - امراض مزمنة اخرى تريد اخبارننا عنها؟  ");
    static JTextField T1 = new JTextField(250);
    static JLabel lbl7 = new JLabel ("other - اخرى  ");
    static JTextField T2= new JTextField();
    
   static JButton nxt = new JButton("Next - التالي"); 
   static JButton pre = new JButton("Previous - السابق"); 
   // Icon pic=new ImageIcon(getClass().getResource("pic.jpg"));
   // private JLabel pictureLbl=new JLabel(pic,SwingConstants.LEFT);

    public UserDetails2 ()
{
        setLayout(new FlowLayout());
        this.setTitle("User Details - معلومات الحاج");
        setVisible(true);
      
        setSize(360, 230);
        p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
         add(p);
        p.add(lbl1);
        p.add(lbl2);
        p.add(lbl3);
        p.add(lbl4);
        p.add(lbl5);
        Qgroup4.add(BU1_4);
        Qgroup4.add(BU2_4);
        p.add(BU1_4);
        p.add(BU2_4);
        p.add(lbl7);
        T2.setSize(150,150);
        p.add(T2);
        BU1_4.addItemListener(this);
        BU2_4.addItemListener(this);
        nxt.addActionListener(this);
        p.add(nxt);
        p.add(pre);
}
  @Override
        public void actionPerformed(ActionEvent e){
                  if(e.getSource() == nxt){
                      
             Service Ser = null;
                      try {
                          Ser = new Service();
                      } catch (URISyntaxException ex) {
                          Logger.getLogger(UserDetails2.class.getName()).log(Level.SEVERE, null, ex);
                      } catch (IOException ex) {
                          Logger.getLogger(UserDetails2.class.getName()).log(Level.SEVERE, null, ex);
                      }
             Ser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             setVisible(false);
             Ser.setSize(660, 630);
            }
                   if(e.getSource() == pre){
                UserDetails2 UD2 = new UserDetails2 ();
             UD2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             UD2.setSize(400,300);
              setVisible(false);
            }  
}

    @Override
    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
