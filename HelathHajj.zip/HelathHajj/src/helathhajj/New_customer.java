/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helathhajj;


import static helathhajj.Login.BU1;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Areej
 */
public class New_customer extends JFrame{
   static JLabel user = new JLabel("Name - الاسم");
    static JLabel pass = new JLabel("password - كلمة السر");
    static JButton BU1 = new JButton("Sign up");
    static JButton pre = new JButton("Previous");
    static JTextField T1 = new JTextField(10);
    static JPasswordField P1 = new JPasswordField(10);
    
    public New_customer(){
    super("Sign up - تسجيل جديد");
    setLayout(new FlowLayout());
    setVisible(true);
    add(user);
    add(T1);
    add(pass);
    add(P1);
    add(BU1);
    add(pre);
    New_customer.ButtonHandler handler = new New_customer.ButtonHandler();
    BU1.addActionListener(handler);
    pre.addActionListener(handler);
    
}

   
  private class ButtonHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource() == BU1){
             UserDetails UD = new UserDetails();
             UD.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
              setVisible(false);
             UD.setSize(400, 300);
              
              
            }
             if(e.getSource() == pre){
                Welcome W = new Welcome();
                setVisible(false);
                W.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                W.setSize(200, 150);
            }  
        }
  }
}
  