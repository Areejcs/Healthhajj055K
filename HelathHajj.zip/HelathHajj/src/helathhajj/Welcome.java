/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helathhajj;

/**
 *
 * @author Areej
 */
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import javax.swing.JPanel;

public class Welcome extends JFrame {

    static JLabel welcome = new JLabel("Welcome to Hajj Healthcare \n مرحبا بك في تطبيق صحة الحاج");
    static JButton BU1 = new JButton("Login - تسجيل دخول");
    static JButton BU2 = new JButton("Sign up - تسجيل جديد ");
    //JPanel contentPane = new JPanel(); 

    public Welcome() {
        super("Welcome to Hajj Healthcare - اهلا بك في تطبيق صحة الحاج");
        setLayout(new FlowLayout());
        //contentPane.setBackground(Color.red);
        setVisible(true);
        add(welcome);
        add(BU1);
        add(BU2);

        ButtonHandler handler = new ButtonHandler();
        BU1.addActionListener(handler);
        BU2.addActionListener(handler);
    }

    private class ButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == BU1) {
                Login LO = new Login();
                setVisible(false);
                LO.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                LO.setSize(200, 200);

            }
            if (e.getSource() == BU2) {
                New_customer NC = new New_customer();
                setVisible(false);
                NC.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                NC.setSize(400, 300);
            }
        }
    }
}
